package com.web.store.register.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.web.store.register.model.registerBean;

public interface regDaoRepository extends JpaRepository<registerBean, Integer>{
	
	registerBean findByAccount(String account);
	
}
