package com.web.store.register.service;

import com.web.store.register.model.registerBean;

public interface regService {
	
	void save(registerBean rb);
	
	registerBean findByAccount(String account);
	
	registerBean findByAccountAndPassword(String account, String password);
	
	boolean exsistByAccount(String account);
	
}
