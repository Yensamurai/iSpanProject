package com.web.store;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigProjectSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigProjectSbApplication.class, args);
	}

}
