package com.web.store.register.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.web.store.register.model.registerBean;

import jakarta.transaction.Transactional;
@Repository
@Transactional
public interface RegisterDaoRepository extends JpaRepository<registerBean, Integer> {
////	@Modifying
////	@Query("UPDATE MemberEntity SET unpaid_amount = unpaid_amount + :totalAmount "
////	 	 + " WHERE memberId = :mid")
////    public void updateUnpaidAmount(@Param("totalAmount") Double totalAmount, 
////    		                 @Param("mid") String mid);

	registerBean findByAccount(String account);

////	Member findByMemberIdAndPassword(String memberId, String password);	
}