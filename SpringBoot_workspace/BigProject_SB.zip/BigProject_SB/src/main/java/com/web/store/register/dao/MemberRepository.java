//package com.web.store.register.dao;
//
//import org.springframework.data.repository.CrudRepository;
//
//import com.web.store.register.model.registerBean;
//
//public interface MemberRepository extends CrudRepository<registerBean, Integer> {
//
//}
