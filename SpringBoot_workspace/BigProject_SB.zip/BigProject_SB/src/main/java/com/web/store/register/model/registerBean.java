﻿package com.web.store.register.model;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;

@Entity
@Table(name="member")
public class registerBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer Id;
	@Column(name = "account")
	private String account;
	private String username;
	private String password;
	private String phone;
	private String mail;
	private Date birthday;
	
//	Timestamp registerTime;
	
	@Transient
	private String password1;
	
	public registerBean() {
		
	};

	

	public registerBean(Integer id, String account, String username, String password, String phone, String mail,
			Date birthday, String password1) {
		super();
		Id = id;
		this.account = account;
		this.username = username;
		this.password = password;
		this.phone = phone;
		this.mail = mail;
		this.birthday = birthday;
		this.password1 = password1;
	}


	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public String getPassword1() {
		return password1;
	}

	public void setPassword1(String password1) {
		this.password1 = password1;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}



//	@Override
//	public String toString() {
//		StringBuilder builder = new StringBuilder();
//		builder.append("MemberBean [id=");
//		builder.append(Id);
//		builder.append(", name=");
//		builder.append(username);
//		builder.append(", password=");
//		builder.append(password);
//		builder.append(", phone=");
//		builder.append(phone);
//		builder.append(", mail=");
//		builder.append(mail);
//		builder.append(", birthday=");
//		builder.append(birthday);
//		
//		return builder.toString();
//	}
	
}
