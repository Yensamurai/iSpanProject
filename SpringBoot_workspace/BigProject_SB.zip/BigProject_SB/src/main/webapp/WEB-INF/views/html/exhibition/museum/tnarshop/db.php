﻿<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "test"; 
$port = "3306";

$conn = mysqli_connect($servername, $username, $password, $dbname, $port);
?>